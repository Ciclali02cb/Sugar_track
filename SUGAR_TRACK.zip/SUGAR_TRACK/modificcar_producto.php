<?php
require_once 'conexion.php'; // Incluye la conexión a la base de datos

if (isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['precio']) && isset($_POST['stock'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];

    $sql = "UPDATE productos SET nombre='$nombre', precio='$precio', stock='$stock' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Producto modificado correctamente";
    } else {
        echo "Error al modificar el producto: " . $conn->error;
    }

    $conn->close();
}
?>