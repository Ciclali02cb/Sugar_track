<!DOCTYPE html>
<html>
<head>
    <title>Sugar Track</title>
    <style>
        body {
            font-family: sans-serif;
            background-color: #e0f2f7; /* Color de fondo agua marina claro */
        }

        h1, h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #458588; /* Color de fondo agua marina oscuro */
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        a {
            text-decoration: none;
            color: blue;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }

        .button-container {
            margin-bottom: 10px;
        }

        .button-container button {
            margin-right: 5px;
        }

        .cita-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); /* Cuadritos ajustables */
            gap: 10px;
        }

        .cita-card {
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <h1>Sugar Track</h1>

    <h2>Productos</h2>
    <div class="button-container">
        <button onclick="agregarProducto()">Agregar Producto</button>
        <button onclick="regresar()">Regresar</button>
        <button onclick="actualizar()">Actualizar</button>

    </div>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Acciones</th>
        </tr>
        <?php
        require_once 'conexion.php'; // Incluye la conexión a la base de datos

        $sql = "SELECT * FROM productos";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["nombre"] . "</td>";
                echo "<td>" . $row["precio"] . "</td>";
                echo "<td>" . $row["stock"] . "</td>";
                echo "<td>
                        <button onclick='eliminarProducto(" . $row["id"] . ")'>Eliminar</button>
                        <button onclick='modificarProducto(" . $row["id"] . ")'>Modificar</button>
                    </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No hay productos disponibles.</td></tr>";
        }
        ?>
    </table>
    <script>
        function agregarProducto() {
            window.location.href = "agregar_producto.php";
        }

        function eliminarProducto(id) {
            if (confirm("¿Estás seguro de que quieres eliminar este producto?")) {
                // Enviar una solicitud AJAX al servidor para eliminar el producto
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "eliminar_producto.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onload = function() {
                    if (this.status == 200) {
                        // Actualizar la tabla de productos
                        // Eliminar la fila correspondiente al producto eliminado
                        // ...
                        alert(this.responseText); // Mostrar mensaje de éxito o error
                    }
                };
                xhr.send("id=" + id);
            }
        }

        function modificarProducto(id) {
            // Mostrar un modal o formulario para modificar los datos del producto
            var nombre = prompt("Ingresa el nuevo nombre del producto:", "");
            var precio = prompt("Ingresa el nuevo precio del producto:", "");
            var stock = prompt("Ingresa el nuevo stock del producto:", "");

            // Validar los datos ingresados

            if (nombre && precio && stock) {
                // Enviar una solicitud AJAX al servidor para modificar el producto
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "modificar_producto.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onload = function() {
                    if (this.status == 200) {
                        // Actualizar la tabla de productos
                        // Reemplazar la fila correspondiente al producto modificado
                        // ...
                        alert(this.responseText); // Mostrar mensaje de éxito o error
                    }
                };
                xhr.send("id=" + id + "&nombre=" + nombre + "&precio=" + precio + "&stock=" + stock);
            }
        }
        
        function regresar() {
            window.location.href = "principal.php";
        }

        function actualizar() {
            // Recargar la página para actualizar la tabla de productos
            location.reload();
        }

    </script>

</body>
</html>