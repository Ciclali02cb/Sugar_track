<!DOCTYPE html>
<html>
<head>
    <title>Sugar Track</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f0f0f0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
        }

        .cita-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 500px;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .cita-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .cita-info label {
            font-weight: bold;
            margin-right: 10px;
        }

        .cita-info span {
            font-size: 1.2em;
            color: #333;
        }

        .cita-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        button {
            background-color: #4CAF50; /* Verde */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }

        button.cancelar {
            background-color: #f44336; /* Rojo */
        }

        .regresar {
            background-color: #008CBA; /* Azul */
        }
    </style>
</head>
<body>
    <div class="cita-container">
        <h1>Agenda tu Cita</h1>

        <?php
        session_start();
        include('conexion.php');

        if (isset($_SESSION['usuarioingresando'])) {
            $usuarioingresado = $_SESSION['usuarioingresando'];
            $buscandousu = mysqli_query($conn, "SELECT * FROM usuarios WHERE correo = '$usuarioingresado'");
            $mostrar = mysqli_fetch_array($buscandousu);

            echo "<div class='cita-info'>";
            echo "<label for='nombre'>Nombre:</label>";
            echo "<span id='nombreCita'>" . $mostrar['nom'] . "</span>";
            echo "</div>";

            echo "<form method='POST' action=''>
                    <div class='cita-info'>
                        <label for='fecha'>Fecha:</label>
                        <input type='date' name='fecha' id='fecha' required>
                    </div>
                    <div class='cita-info'>
                        <label for='hora'>Hora:</label>
                        <input type='time' name='hora' id='hora' required>
                    </div>
                    <button type='submit' name='agendar'>Agendar Cita</button>
                </form>";

            if (isset($_POST['agendar'])) {
                $fecha = $_POST['fecha'];
                $hora = $_POST['hora'];

                $sql = "INSERT INTO solicitudes_citas (nombre, fecha, hora, estado) VALUES ('" . $mostrar['nom'] . "', '$fecha', '$hora', 'pendiente')";

                if (mysqli_query($conn, $sql)) {
                    echo "<p>Cita agendada correctamente.</p>";
                } else {
                    echo "<p>Error al agendar la cita.</p>";
                }
            }
        } else {
            header('location: index.php');
        }
        ?>

        <div class="cita-buttons">
            <button onclick="regresar()" class="regresar">Regresar</button>
        </div>
    </div>

    <script>
        function regresar() {
            window.location.href = "principal.php";
        }
    </script>
</body>
</html>