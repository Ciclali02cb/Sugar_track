<!DOCTYPE html>
<html>
<head>
    <title>Sugar Track - Quejas</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f0f0f0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
        }

        .quejas-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 80%;
            max-width: 800px;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #4CAF50; /* Verde */
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        button {
            background-color: #008CBA; /* Azul */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }
    </style>
</head>
</head>
<body>
    <div class="quejas-container">
        <h1>Lista de Quejas</h1>

        <?php
        session_start();
        include('conexion.php');

        if (isset($_SESSION['usuarioingresando'])) {
            $sql = "SELECT * FROM quejas";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Mensaje</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>";
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>" . $row['id'] . "</td>
                            <td>" . $row['nombre'] . "</td>
                            <td>" . $row['correo'] . "</td>
                            <td>" . $row['mensaje'] . "</td>
                            <td>" . ($row['estado'] == 'pendiente' ? 'Pendiente' : 'Queja Atendida') . "</td>
                            <td>
                                <button onclick='cambiarEstado(" . $row['id'] . ")'>
                                    " . ($row['estado'] == 'pendiente' ? 'Verificar' : 'Desmarcar') . "
                                </button>
                            </td>
                        </tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No hay quejas registradas.</p>";
            }

            mysqli_close($conn);
        } else {
            header('location: index.php');
        }
        ?>

        <button onclick="regresar()" class="regresar">Regresar</button>
    </div>

    <script>
        function regresar() {
            window.location.href = "principal.php";
        }
        
        function cambiarEstado(id) {
            // Enviar una solicitud AJAX al servidor para cambiar el estado de la queja
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "cambiar_estado_queja.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function() {
                if (this.status == 200) {
                    // Actualizar la tabla de quejas
                    var fila = document.querySelector(`tr[data-id="${id}"]`);
                    var estadoCelda = fila.querySelector(`td[data-estado]`);
                    var estadoActual = estadoCelda.dataset.estado;

                    // Actualizar el texto del estado
                    estadoCelda.textContent = (estadoActual == 'pendiente' ? 'Queja Atendida' : 'Pendiente');
                    estadoCelda.dataset.estado = (estadoActual == 'pendiente' ? 'verificado' : 'pendiente');

                    // Actualizar el texto del botón
                    var boton = fila.querySelector('button');
                    boton.textContent = (estadoActual == 'pendiente' ? 'Desmarcar' : 'Verificar');

                    alert(this.responseText); // Mostrar mensaje de éxito o error
                }
            };
            xhr.send("id=" + id);
        }
    </script>
</body>
</html>