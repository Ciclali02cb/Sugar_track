<?php
require_once 'conexion.php';

if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // Obtener el estado actual de la queja
    $sql = "SELECT estado FROM quejas WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $estadoActual = $row['estado'];

    // Actualizar el estado de la queja
    $nuevoEstado = ($estadoActual == 'pendiente' ? 'verificado' : 'pendiente');
    $sql = "UPDATE quejas SET estado = '$nuevoEstado' WHERE id = $id";

    if (mysqli_query($conn, $sql)) {
        echo "Estado de la queja actualizado correctamente.";
    } else {
        echo "Error al actualizar el estado de la queja.";
    }

    mysqli_close($conn);
}
?>