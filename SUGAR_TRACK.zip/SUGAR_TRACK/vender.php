<?php
require_once 'db_config.php';

if (isset($_GET['id'])) {
    $producto_id = $_GET['id'];

    $sql = "SELECT * FROM productos WHERE id = $producto_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if (isset($_POST['cantidad'])) {
            $cantidad = $_POST['cantidad'];

            if ($cantidad > 0 && $cantidad <= $row['stock']) {
                // Actualizar stock
                $nuevo_stock = $row['stock'] - $cantidad;
                $sql = "UPDATE productos SET stock = $nuevo_stock WHERE id = $producto_id";
                if ($conn->query($sql)) {
                    // Registrar venta
                    $sql = "INSERT INTO ventas (producto_id, cantidad, fecha) VALUES ($producto_id, $cantidad, NOW())";
                    if ($conn->query($sql)) {
                        echo "Venta exitosa!";
                    } else {
                        echo "Error al registrar la venta.";
                    }
                } else {
                    echo "Error al actualizar el stock.";
                }
            } else {
                echo "Cantidad inválida.";
            }
        } else {
            ?>
            <h2>Vender <?php echo $row['nombre']; ?></h2>
            <form action="" method="POST">
                <label for="cantidad">Cantidad:</label>
                <input type="number" name="cantidad" id="cantidad" min="1" max="<?php echo $row['stock']; ?>" required><br>
                <button type="submit">Vender</button>
            </form>
            <?php
        }
    } else {
        echo "Producto no encontrado.";
    }
} else {
    echo "ID de producto no válido.";
}
?>