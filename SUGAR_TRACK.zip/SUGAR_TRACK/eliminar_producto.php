<?php
require_once 'conexion.php'; // Incluye la conexión a la base de datos

if (isset($_POST['id'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM productos WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "Producto eliminado correctamente";
    } else {
        echo "Error al eliminar el producto: " . $conn->error;
    }

    $conn->close();
}
?>