<!DOCTYPE html>
<html>
<head>
    <title>Sugar Track</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f0f0f0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
        }

        .queja-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 500px;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .queja-form {
            margin-bottom: 20px;
        }

        .queja-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .queja-form input[type="text"],
        .queja-form textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            margin-bottom: 10px;
        }

        .queja-form textarea {
            height: 100px;
        }

        button {
            background-color: #4CAF50; /* Verde */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }

        button.regresar {
            background-color: #008CBA; /* Azul */
        }
    </style>
</head>
<body>
    <div class="queja-container">
        <h1>Enviar Queja</h1>

        <?php
        session_start();
        include('conexion.php');

        if (isset($_SESSION['usuarioingresando'])) {
            $usuarioingresado = $_SESSION['usuarioingresando'];
            $buscandousu = mysqli_query($conn, "SELECT * FROM usuarios WHERE correo = '$usuarioingresado'");
            $mostrar = mysqli_fetch_array($buscandousu);

            if (isset($_POST['enviar_queja'])) {
                $queja = $_POST['queja'];

                $sql = "INSERT INTO quejas (nombre, correo, mensaje) VALUES ('" . $mostrar['nom'] . "', '" . $mostrar['correo'] . "', '$queja')";

                if (mysqli_query($conn, $sql)) {
                    // Mostrar mensaje de éxito con nombre y correo
                    echo "<p>Su queja ha sido enviada correctamente, " . $mostrar['nom'] . " (" . $mostrar['correo'] . ").</p>";
                } else {
                    echo "<p>Error al enviar la queja.</p>";
                }
            } else {
                echo "<form class='queja-form' method='POST' action=''>
                        <label for='queja'>Mensaje:</label>
                        <textarea name='queja' id='queja' required></textarea>
                        <button type='submit' name='enviar_queja'>Enviar Queja</button>
                    </form>";
            }
        } else {
            header('location: index.php');
        }
        ?>

        <div class="cita-buttons">
            <button onclick="regresar()" class="regresar">Regresar</button>
        </div>
    </div>

    <script>
        function regresar() {
            window.location.href = "principal.php";
        }
    </script>
</body>
</html>