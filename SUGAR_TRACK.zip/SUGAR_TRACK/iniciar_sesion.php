<?php
// Incluir la conexión a la base de datos
require_once 'config_db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    // Preparar y ejecutar la consulta SQL para recuperar al usuario
    $sql = "SELECT * FROM usuarios WHERE correo = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $usuario = $result->fetch_assoc();
        if (password_verify($contrasena, $usuario['contrasena'])) {
            // Autenticación exitosa
            session_start();
            $_SESSION['id_usuario'] = $usuario['id'];
            // Si tu base de datos tiene un campo para el rol del usuario, agrega: 
             $_SESSION['rol'] = $usuario['rol']; 

            // Redireccionar a la página correspondiente según el rol del usuario
            // Si tienes roles, usa:
             if ($usuario['rol'] === 'admin') {
                 header("Location: panel_admin.php"); 
             } else {
                 header("Location: panel_cliente.php"); 
             }
            header("Location: inicio.php"); // Reemplazar con tu página principal o panel de usuario
            exit;
        } else {
            // Contraseña incorrecta
            echo "Contraseña incorrecta.";
        }
    } else {
        // Usuario no encontrado
        echo "Usuario no encontrado.";
    }

    $stmt->close();
}
?>